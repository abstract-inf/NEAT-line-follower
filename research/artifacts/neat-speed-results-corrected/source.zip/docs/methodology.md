# Line following experiment methodology

This is the working methods record for the paper. It connects the controller and evaluator code to each experiment's protocol and evidence. Each run's saved protocol and source snapshot are the authority for its exact settings.

## Research questions and experiment record

The main question is how a learned NEAT controller compares with sensor-based PID on unseen line following courses under matched simulation conditions. The speed experiment asks whether additional evolution from g94 improves completion and actual driving speed when the wheel speed cap rises.

| Experiment | Method and evidence |
| --- | --- |
| Historical NEAT and zigzag diagnosis | The original 100-generation run and 74 completed continuation generations produced the previously selected g109 controller. The research report records configuration changes, seen versus held-out tracks, and the corner failure diagnosis. [Historical NEAT results](../research/NEAT_Experimental_Results.md) · [Corner diagnosis](../runs/diagnostics/zigzag-20261029/report.md) |
| PID development and frozen comparisons | Bounded searches produced filtered PID and corner-supervised PID baselines. The original comparison and later gain tuning used distinct test cohorts, each with 90 tracks. Compare controllers within each matched cohort. [PID implementation](../research/PID_Controller_Methodology.md) · [Initial protocol](../research/PID_Protocol.md) · [Gain tuning protocol](../research/PID_Gain_Tuning_Protocol.md) · [Matched results](../research/NEAT_PID_Comparison.md) |
| Fresh NEAT corner run | A fresh population of 96 evolved for 100 generations at 0.35 m/s. Four shared courses per generation included three short corner drills and a separate procedural course. The selected g94 finished 30/30 validation tracks and 88/90 fresh test tracks. Four frozen comparators ran on the same test tracks. [Training protocol](corner-training.md) · [Results](../research/NEAT_Corner_Results.md) · [Reproducible figures](../research/NEAT_Corner_Plots.ipynb) |
| Warm start with increasing speed | The run finished 100 generations from one exact g94 copy and 99 independently mutated copies. The wheel speed cap rose from 0.50 to 1.50 m/s. The final g98 checkpoint finished 75/90 at 1.50 m/s. A retrospective extension compared phase winners, plain PID, and filtered PID with recovery on the same 90 geometries. [Training guide](speed-training.md) · [Results and notebooks](../research/NEAT_Speed_Results.md) · [Frozen run protocol](../runs/neat-speed-100-20261104/protocol.json) |

The fresh corner run changed several elements together, including the controller inputs and action mapping, training tracks, and evolutionary settings. Treat its comparison with g109 as a comparison of frozen controllers. A change in the warm-start run also bundles added evolution with the new training schedule. Independent runs or controlled comparisons are needed to estimate run-to-run variation or attribute gains to one design choice.

## Shared simulation and controller interface

The competition robot is a simulated 0.55 kg differential-drive chassis with a passive caster, 175 mm wheel spacing, and 16.5 mm wheel radius. MuJoCo advances at 600 Hz and the controller receives observations at 60 Hz. Fifteen binary reflectance sensors sample the painted floor at their actual poses. The controller receives the readings and control interval. The evaluator uses simulator pose and the ordered route to measure performance. [Geometry and sensor mount](sensor-mount.md) · [Simulator](../line_follower/simulation.py)

The wheel commands are scaled by the active rim speed target cap. The speed controller uses a 50 ms actuator filter and a 0.03 N·m torque limit per wheel. Distinguish the requested wheel speed cap from measured chassis speed in all figures and tables. The corner benchmark used a 0.35 m/s cap. The warm-start protocol changes the cap on a fixed generation schedule while retaining the robot geometry, actuator limits, and episode settings. [Physical parameters](../line_follower/config.py) · [Action mapping](../line_follower/simulation.py)

NEAT g94 and its descendants use a feedforward network with 21 inputs derived from the 15 physical sensors. The six added signals represent the current and last visible line centroids, recent edge evidence, line loss duration, and the previous drive and steering commands. The controller mirrors observations to share experience across turn directions, resets its history every episode, and mixes two tanh outputs into signed wheel commands. The research PID comparators use the same physical readings. Filtered PID includes derivative filtering and line loss recovery. The supervised variants add explicit corner handling. [NEAT implementation](../line_follower/controllers.py) · [PID implementation](../line_follower/pid.py)

## Tracks, selection, and metrics

- **Training.** All genomes in a generation face the same batch. Fresh tracks come from deterministic seeds. Track geometry hashes help exclude duplicate routes, including mirrored variants, from protected splits. The speed run uses one beginner, one intermediate, and two advanced tracks per generation. One intermediate and one advanced slot guarantee zigzags. [Track generator](../line_follower/tracks.py) · [Split and batch logic](../line_follower/suites.py)
- **Validation.** Evaluate each generation's training champion on the same 30 validation courses. Rank checkpoints by validation completion, then by validation fitness. During speed training, restart that ranking at each cap and select the final model from generations 70–99. Retain the per-generation results to see changes across phases. [Training and selection loop](../line_follower/experiments.py)
- **Final test.** Freeze the selected model before opening the final test geometry. Use a fresh suite of 90 tracks with 30 per difficulty and identical track hashes across the compared conditions. The speed experiment evaluates g94 and the new model at both 0.50 and 1.50 m/s on those 90 tracks, for 360 paired records. Keep exploratory tracks and replay outcomes labeled separately from the final comparison. [Speed assessment](../run_speed_training.py)
- **Completion and progress.** The evaluator checks ordered route gates and tracks the greatest authenticated progress. Both recent NEAT runs use a 45 mm corridor half-width, a 35 mm gate radius, and termination after one second continuously outside the corridor or five seconds without 10 mm of new progress. The timeout is route length divided by 0.10 m/s, bounded to 45–120 seconds. Also record tips and technical errors separately. [Episode loop](../line_follower/episodes.py) · [Route projection and gates](../line_follower/fitness.py)
- **Training fitness.** The episode score combines authenticated progress, a completion bonus, elapsed time relative to the timeout, and a small bounded legacy term. Both recent NEAT runs combine the average score of the four tracks and the average of the two worst tracks with equal weight. [Fitness equations](../line_follower/fitness.py)
- **Reporting.** Report completion counts and denominators, progress, and failure reasons. Compare completion time on the tracks both controllers finish and state the shared denominator. Lateral RMSE and MAE summarize observed tracking error per episode. Report whether the aggregation includes failures or uses shared finishes. Keep the training seed, track, and telemetry sample distinct as units of analysis. [Episode fields](../line_follower/episodes.py) · [Assessment metrics](../line_follower/pid_experiments.py)

## Exploratory speed check

Before the warm-start run, frozen g94 was evaluated at six speed caps on the same 12 newly generated pilot tracks, four per difficulty. The pilot used `derived_seed(2026110403, "speed-pilot", index, attempt)`, indices 0–11 in beginner, intermediate, advanced rotation, skipping failed generation attempts and geometry hashes already used or protected by the corner run. The robot and episode settings came from the g94 artifact.

| Wheel target cap | Completed |
| --- | ---: |
| 0.35 m/s | 12/12 |
| 0.50 m/s | 12/12 |
| 0.65 m/s | 12/12 |
| 0.80 m/s | 6/12 |
| 1.00 m/s | 5/12 |
| 1.50 m/s | 0/12 |

On a separate 2.5 m straight, g94 reached about 1.50 m/s with the highest cap. The pilot motivated starting at 0.50 m/s and reserving the final 30 generations for 1.50 m/s. It measured transfer of frozen g94 and served as a development check for the new protocol.

## What to record for each experiment

Video review on 5 November 2026 exposed false off-route failures in the original speed evaluation. A missed corner gate could leave the ordered cursor behind a robot that was still following the route. Evaluator `progress-1.2` increases gate tolerance to cover accepted corner cuts and resets departure time whenever line sensors are active. The corrected video assessment uses a 100 mm corridor and two seconds of continuous departure with no sensor contact for every controller. Its [protocol, full telemetry, and previous-versus-current episode outcomes](../research/artifacts/neat-speed-videos/README.md) document this retrospective change. Original 90-track rankings remain historical results under the earlier evaluator.

1. **Before launch.** Record the research question, comparison, intended changes and rationale, population and generation budget, seeds, controller and robot settings, split manifest and selection rule, metrics and their units. Mark pilots and planned comparisons explicitly.
2. **During the run.** Keep source and dependency versions, run protocol, actual episode counts, route files and geometry hashes, checkpoints, and any interruptions or deviations. Use the saved logs for changes in speed, curriculum or evaluation backend.
3. **After the run.** Record the selected model hash, generation and validation result, then verify the final test file and matched tracks. Preserve failures, separate final results from exploratory checks, and link the report, plotting code, and figures. Keep run archives with the repository because the run directories are ignored by Git.

The reproducibility trail is `protocol.json` → `suite/suite.json` → `training/run.json`, `training/source.zip`, and the training CSVs → `assessment/selection-freeze.json` and `assessment/test-episodes.csv`. The simulation supports claims about these courses under the recorded conditions. Hardware performance, disturbance tolerance, and reproducibility across evolution seeds require their own evidence.

The [historical implementation record](research-record.md) covers the PyGame-to-MuJoCo transition, earlier defaults, and engineering validation.
