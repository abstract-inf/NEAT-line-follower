# Reproducible experiment ledger

This ledger records the autonomous development work requested after the old/smooth pilot comparison. Every new run must retain its protocol before evaluation or evolution, source/input hashes, dependencies, seed, exact commands, raw outcomes, model selection rule and interpretation. Unsuccessful experiments remain in the record. Development/validation data may guide the next protocol; final test data must not.

## Preserved predecessors

| ID | Protocol / evidence | Status and interpretation |
|---|---|---|
| SMOOTH-V1-AUDIT | `runs/neat-smooth-study-v1/prepared/protocol.json`; `results/neat-smooth-study-v1/audit-report.md` | 14 archived candidates audited. None met the combined speed/quality target. |
| SMOOTH-V1-OLD | `runs/neat-smooth-study-v1/pilot/seed-01/old/`; `results/neat-smooth-study-v1/pilot-old-100-generations/report.md` | 100 generations, 60,000 training + 8,000 validation episodes. No qualifier. |
| SMOOTH-V1-SMOOTH | `runs/neat-smooth-study-v1/pilot/seed-01/smooth/`; `results/neat-smooth-study-v1/pilot-comparison/report.md` | 100 generations, 60,012 training + 8,000 validation episodes. 84 champions passed straight yaw/steering, but none met the whole target. |

The original fixed inputs, outputs and frozen execution source are preserved. No retrospective edits to reward, selection thresholds or recorded outcomes are permitted.

Earlier experiments retain their original detailed records rather than being reconstructed from memory:

| Experiment family | Reproduction / interpretation record | Saved data area |
|---|---|---|
| Low-speed and short-ramp five-seed study | [Methodology and terminal commands](methodology.md) | `runs/neat-speed-study/` |
| 300-generation fast curriculum and five-lineage repetitions | [Fast-study protocol](fast-neat-study.md), [repeat and memory-recovery record](fast-neat-repeats.md) | `runs/neat-fast-study/` |
| Sensor-position geometry pilots | [Geometry protocol](geometry-pilot-protocol.md), [geometry results](geometry-pilot-results.md) | `runs/geometry-pilot-v1/`, `runs/geometry-pilot-v2/` |
| Older implementation, dynamics and evaluation changes | [Research implementation record](research-record.md) | The dated run directories referenced there |
| Long exploratory competition courses | [Course choices, geometry and commands](long-course-candidates.md) | `runs/long-course-candidates-20261121/`, `runs/rhythm-changes-case-study-20261121/` |
| Smooth versus original reward, full-speed PID protocol | [Smooth-study workflow and results](neat-smooth-study.md) | `runs/neat-smooth-study-v1/`, `results/neat-smooth-study-v1/` |

These links are an index of preserved historical records, not a claim that old protocols all used the current fitness, speed law, termination logic or reproduction guarantees. Use each run's frozen source and inputs for repetition. Replaying an old genome with today's source is a new evaluation condition and must be identified as such.

## Goal-development experiments

### PID-1M-VALID-001 — validate the established full-cruise PID

Question: does the saved base-1.0 filtered PID satisfy the frozen fresh PID validation rule? Reuse the already prepared tuning protocol and suite, not NEAT's final test tracks.

```powershell
& .\.venv\Scripts\python.exe run_neat_smooth_study.py tune-pid --cap 1.0 --workers 4
```

This existing frozen command first evaluates the established tune; if it is eligible, it retains it. If not, it executes the predeclared, deterministic PID search. Completion, every isolated-straight speed window and observed quality metrics are retained. Output: `runs/neat-smooth-study-v1/pid/cap-100/`. No new PID family or privileged controller input is introduced.

Outcome: the existing full-speed tune passed 60/60 PID validation courses, with minimum dedicated-straight speed 0.9905 m/s. It was retained without retuning. The frozen config SHA-256 is `c6c68b53342600db0078e991bbb729064d829d360c4840a720dbf5e66d94c24b`. See `runs/neat-smooth-study-v1/pid/cap-100/selection-freeze.json`. This PID-validation suite is distinct from the shared development comparison below.

### QUALITY-SPEED-V1 — calibrate and test constraint-aware task fitness

Development question: can a stock NEAT controller preserve acceptable tracking/smoothness while raising sustained straight speed to at least 0.95 m/s under the 1 m/s cap? The preceding smooth g83 is a disclosed development warm start, not a fresh independent winner.

Before evolution: document the exact scalar objective, plateau below quality limits, failure ordering, reference measurements, seeds, course splits and pilot budget. Rescore stored episodes and test synthetic counterexamples; do not choose weights against final test outcomes. Keep stock NEAT mutation/reproduction and existing controller inputs/action mapping. All physical route/error information belongs exclusively to the evaluator/fitness, not the neural inputs.

The source, inputs and new execution tree will be frozen in a distinct run directory. Existing v1 control results remain preserved. A 50-generation development pilot is the initial intended budget; all actual population and episode counts must be reported. Five-lineage confirmation and a fresh PID comparison follow only after the training/selection protocol is settled. If the pilot fails, record it and version the next experiment explicitly.

Implementation and calibration completed: 55 regression checks passed, including nine new objective/checkpoint checks. The full equations, commands, assumptions, data roles and interruption rules are in [the quality-speed methodology](neat-quality-speed-study.md). The 200 stored development champions were rescored before preparation; this is retrospective calibration, not new test evidence.

The protocol and execution source are frozen in `runs/neat-quality-speed-v1/prepared/`; `launch-record.json` records the authorized 50-generation, six-worker command and prelaunch checks. The live stage is `development/seed-01/`. Its checkpoints/logs, rather than this static ledger, determine current progress. No automatic extension or post-hoc acceptance relaxation is allowed.

Completed outcome, recorded 25 November 2026: all 50 generations committed with 30,000 candidate training episodes, 300 reference episodes and 7,840 complete cache-backed validation episodes (98 distinct genotypes, 150 candidate records). No candidate passed every original gate; all 150 missed required straight speed. The fastest candidate rejected only for speed was g40 rank 0, genotype `58815ae4f4efeab17dac70046f418488785e6199326de2423d0c28d772bf8aa9`: 60/60 primary and 20/20 retention completions, minimum straight speed 0.8841878 m/s, worst yaw RMS 0.0837191 rad/s, steering RMS 0.0114571, paired time ratio 1.0102969, shared-finish geometric RMSE 14.1514 mm and mean command jitter 0.0062963. Compared with the original g83 warm start, straight speed improved from 0.7135 m/s, with a disclosed increase in geometric RMSE. It is not promoted to an official winner. Full records and PNG/SVG figures are in `results/neat-quality-speed-v1/training/`.

### QUALITY-SPEED-V1-BASELINE — shared development comparison

Command: `& .\.venv\Scripts\python.exe run_neat_quality_study.py baseline --workers 6`.

Controllers were frozen before 240 deterministic evaluations (60 primary plus 20 retention for each of stable NEAT g83, fast NEAT g134 and the saved full-speed PID). Primary completion was 60/60, 60/60 and 59/60, respectively. The PID's one failure was off-route. This is a previously consulted development suite, not fresh final testing; it does not contradict PID's 60/60 on its separate tuning-validation suite. Raw episodes, matched finish-time denominators and frozen hashes are under `runs/neat-quality-speed-v1/baseline-development/`. The auxiliary PID 0.5 m/s run transfers its 1 m/s gains and is not called a cap-specific tune.

### PID-050-FULL-001 — cap-specific low-speed comparison baseline

Command: `& .\.venv\Scripts\python.exe run_neat_smooth_study.py tune-pid --cap 0.5 --workers 1`.

Use the existing frozen tuning protocol, development/validation splits, deterministic candidate grid and refinement schedule. All candidates have `base=1.0`; this replaces the inappropriate restricted-cruise historical tune for any later cap-specific 0.5 m/s comparison. One worker is used concurrently with the six-worker NEAT development run to limit memory pressure. Candidate results, seed, bounds, failures and final eligibility remain under `runs/neat-smooth-study-v1/pid/cap-050/`. This is baseline development, not final-test tuning. Inspect its final selection/failed record before claiming a validated tune.

Completed outcome: `refine2-169` was selected after 130 coarse candidates, 12 expanded candidates, two sets of 24 refinements and 10 validation finalists. It completed 60/60 validation tracks, with minimum dedicated-straight speed 0.4952560 m/s. Saved config `pid-fullspeed.json` SHA-256 is `7777c1c55f24102672c4689135cc6cb9d4cf95f2a63ad9fd32666f22b68c6295`. This is a validated historical baseline; the user's subsequent request to address the Rhythm Changes case motivates a separate further PID tuning version, preserving this result.

### QUALITY-NETWORK-001 — offline architecture diagnostics

Command: `& .\.venv\Scripts\python.exe research/analyze_quality_networks.py`.

Inspect both frozen predecessor networks and all candidates from logged development generations. Record node/connection counts, graph reachability, whether stock NEAT-Python actually evaluates each output, and deterministic constant-sensor probes. Each probe resets history, holds one sensor active for 180 steps at 60 Hz, then records wheel commands. No physics or evolution is executed. These commands are not measured robot speeds and are not used to select the experiment winner. Output and input-model/reporting-source hashes: `results/neat-quality-speed-v1/training/network-diagnostics.json`. Regenerate after evolution for complete coverage. This preserves the existing 0.92 handling of disconnected nodes.

The same diagnostics command records the 25 installed NEAT Python source hashes and checks them against the distribution's installation `RECORD`; all 25 matched for version 0.92. Evidence: `results/neat-quality-speed-v1/neat-runtime-source-integrity.json`. This supplements package version pinning and does not claim independent authentication of the installation manifest. A separate read-only audit of frozen fitness, source/input hashes, validation decisions, actual caps and counts is in `research/Quality_Speed_V1_Audit.md`. The preparation ZIP was extracted into a clean separate directory and its nested frozen `verify` command passed; the original ZIP was preserved.

### QUALITY-OBJECTIVE-DIAGNOSTIC-001 — offline ranking counterfactual

Command: `& .\.venv\Scripts\python.exe research/diagnose_quality_objective.py`.

Conditional proposal only: preserve the incomplete V1 score and rescore completed batches with `10*m + 9*S/(1+V)`, using exactly the already measured speed utility and quality violation. This removes the feasibility-band jump without changing thresholds or stock NEAT operators. It has not been used for evolution and does not demonstrate a better controller. The script snapshots and hashes the exact captured inputs and its own source, filters to logged generations and supports exact snapshot replay. Saved genome rankings cannot reveal the validation outcomes of unsaved alternate candidates or predict a new evolutionary trajectory. The initial interim snapshot spans generations 0–38 and is preserved under `results/neat-quality-speed-v1/objective-diagnostic/snapshots/`; refresh after completion for the complete diagnostic. Its seven synthetic ordering checks and snapshot replay passed. No V2 experiment has been registered or launched by this diagnostic.

### QUALITY-G21-PID-DEVELOPMENT-001 — compare the saved near qualifier

The training report's named fastest candidate rejected only for straight speed is generation 21, rank 1, genotype `369c307f11d669f6a8c7913c2d8f83b163466b4a34d098207c5e01200d3803d0`. Compare its saved episodes with the frozen full-speed PID and original fast g134 on the same 60 primary development geometries/groups at 1 m/s. No new simulation, training or controller selection occurs. The candidate remains unofficial: minimum required-window speed is 0.87214 m/s, below 0.95.

Outcome: g21/PID completion 60/60 versus 59/60. On 59 shared finishes, mean completion time is 6.0921 versus 7.1226 seconds, mean per-course geometric RMSE 13.988 versus 20.565 mm, and command jitter 0.0061896 versus 0.0011714. PID has substantially lower jitter. Worst straight yaw RMS is 0.0984 versus 0.0744 rad/s; the original fast NEAT reference reaches 1.3956. These reused selection data support no fresh-test or algorithm-wide superiority claim.

Evidence, fixed controller/input/source hashes, numerical results, paired PNG/SVG plots and exact replay commands are in `results/neat-quality-speed-v1/candidate-pid-development/report.md`. Immutable snapshot `cfc2659d90bb4df9be692246831547704ab0933153c0cd064d515d1fb61e4467` retains the consumed episodes, model/gain bytes, protocol/suite, training report and reporting script. Snapshot replay reproduced identical numerical JSON. The separate pre-evolution baseline report is preserved unchanged.

### QUALITY-G40-PID-DEVELOPMENT-001 — completed-budget near qualifier

After the full 50-generation budget, apply the same disclosed near-qualifier rule. G40 rank 0 reaches 0.8841878 m/s and remains unqualified. Completion is g40/PID/fast g134 = 60/59/60. On the 59 shared g40/PID successes, mean times are 6.053672 / 7.122599 s, mean per-course geometric RMSE 14.197061 / 20.565365 mm and jitter 0.00627033 / 0.001171425. PID retains substantially lower jitter. Snapshot `b070af2d238cadb8b479532d5a59e65725341f38dff34127a5f7976ab303f99a` preserves the exact inputs and generalized reporting source under `results/neat-quality-speed-v1/candidate-g40-pid-development/`. Numerical replay matched exactly; the earlier g21 snapshot/output is preserved. These are development comparisons, not new test episodes or independent training repetitions.
