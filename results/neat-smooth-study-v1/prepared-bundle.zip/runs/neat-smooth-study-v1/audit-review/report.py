"""Summarize the completed archive audit without simulating or evolving."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from statistics import mean

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


RUN = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
PARENTS = (134, 136, 131, 107, 134)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    protocol_sha = sha(RUN / 'prepared/protocol.json')
    entries = read(RUN / 'prepared/pilot/suite/suite.json')['splits']['validation']
    kinds = {entry['geometry_hash']: entry['kind'] for entry in entries}
    completed = read(RUN / 'audit/complete.json')
    rows = []
    inputs = {'audit/complete.json': sha(RUN / 'audit/complete.json')}
    for path in sorted((RUN / 'audit').glob('s*-g*.json')):
        record = read(path)
        assert record['protocol_sha256'] == protocol_sha
        assert record['model_sha256'] == sha(RUN / 'prepared' / record['file'])
        inputs[str(path.relative_to(RUN))] = sha(path)
        groups = {}
        for kind in ('isolated', 'post_turn'):
            windows = [w for episode in record['primary']
                       if kinds[episode['track_hash']] == kind
                       for w in episode['straight_windows']]
            observed = [w for w in windows if w['observed']]
            groups[kind] = {'windows': len(windows), 'observed': len(observed)}
            for key in ('speed_m_s', 'yaw_rms_rad_s', 'steering_rms'):
                values = [w[key] for w in observed]
                groups[kind][key] = {'mean': mean(values), 'min': min(values), 'max': max(values)}
        rows.append({'seed': record['seed'], 'generation': record['generation'],
                     'primary_completed': sum(r['completed'] for r in record['primary']),
                     'retention_completed': sum(r['completed'] for r in record['retention']),
                     'quality': record['quality'], 'straight_groups': groups})
    assert len(rows) == completed['candidates'] == 14
    reasons = Counter(reason for row in rows for reason in row['quality']['reasons'])
    summary = {'date': '2026-11-24', 'protocol_sha256': protocol_sha,
               'verified_input_hashes': inputs, 'qualified': len(completed['qualified_existing']),
               'failure_reason_model_counts': dict(reasons), 'candidates': rows,
               'scope': 'Repeated validation audit, not fresh final-test or PID-comparison evidence.'}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')

    labels = [f"S{r['seed']} g{r['generation']}" + (' *' if r['generation'] == PARENTS[r['seed']-1] else '') for r in rows]
    fig, axes = plt.subplots(2, 1, figsize=(12, 7), sharex=True, layout='constrained')
    x = np.arange(len(rows))
    for kind, color, offset, label in (
            ('isolated', '#007f86', -.12, 'Isolated straight'),
            ('post_turn', '#c45a28', .12, 'Straight after turn/chicane')):
        for ax, key in zip(axes, ('speed_m_s', 'yaw_rms_rad_s')):
            values = [r['straight_groups'][kind][key] for r in rows]
            means = np.array([v['mean'] for v in values])
            errors = np.array([[v['mean']-v['min'] for v in values],
                               [v['max']-v['mean'] for v in values]])
            ax.errorbar(x+offset, means, yerr=errors, fmt='o', markersize=4,
                        capsize=3, color=color, label=label)
            ax.grid(axis='y', alpha=.2)
    axes[0].axhline(.95, color='#444', linestyle='--', label='Minimum: 0.95 m/s')
    axes[1].axhline(.15, color='#444', linestyle='--', label='Maximum: 0.15 rad/s')
    axes[0].set(ylabel='Sustained chassis speed (m/s)', ylim=(.65, 1.02),
                title='Archived 1 m/s NEAT models: smooth centered starts, oscillatory recovery after turns')
    axes[1].set(ylabel='Physical yaw RMS (rad/s)', xlabel='Archived model (* = seed-specific parent)')
    axes[1].set_xticks(x, labels, rotation=50, ha='right')
    for ax in axes:
        ax.legend(fontsize=8, loc='upper left', ncol=3)
    axes[1].legend(fontsize=8, loc='upper right', ncol=3)
    for extension in ('png', 'svg'):
        fig.savefig(OUT / f'straight-recovery-audit.{extension}', dpi=180, bbox_inches='tight')
    plt.close(fig)

    text = [
        '# Archived NEAT speed and smoothness audit — 24 November 2026', '',
        '**Complete: 0 of 14 archived candidates passed every predeclared gate.**', '',
        'This audit evaluated 14 historical native-1 m/s champions and five seed-specific parent references. Each controller used 60 primary validation episodes at a 1 m/s cap and 20 retention episodes at 0.5 m/s: 1,520 evaluated episodes including references. These are validation data used for selection, not fresh final-test results.', '',
        '## Findings', '',
        '- All 14 candidates completed 58–60/60 primary tracks and 20/20 retention tracks.',
        '- Every candidate failed the required per-window straight speed, physical yaw and steering gates somewhere. No required straight window was missing.',
        '- All perfectly centered isolated straights had effectively zero yaw and steering oscillation. Every candidate exceeded the yaw and steering thresholds on at least some post-turn recovery straights. This identifies a recovery-related weakness in these conditions; it does not establish behavior under arbitrary perturbations.',
        '- Seed 1 generation 134 sustained 0.972 m/s on isolated straights but only 0.830 m/s after turns. Its mean recovery yaw RMS was 1.319 rad/s versus the 0.150 limit. Small tracking error alone therefore does not establish smooth physical motion.',
        '- The other four frozen parents averaged only 0.857–0.923 m/s even on isolated straights. The issue is both achieved speed and post-turn smoothness.',
        '- Across the 14 candidates, additional rejection reasons were paired lap time (5 models), increased command jitter (3), fewer mixed-track completions (2), and increased shared-finish geometric RMSE (1). Reason counts overlap.', '',
        '## Five frozen starting parents', '',
        '| Seed / generation | Primary completed | Retention completed | Isolated speed (m/s) | Post-turn speed (m/s) | Post-turn yaw RMS (rad/s) |',
        '|---|---:|---:|---:|---:|---:|',
    ]
    for row in rows:
        if row['generation'] != PARENTS[row['seed']-1]:
            continue
        groups = row['straight_groups']
        text.append(f"| {row['seed']} / {row['generation']} | {row['primary_completed']}/60 | {row['retention_completed']}/20 | {groups['isolated']['speed_m_s']['mean']:.3f} | {groups['post_turn']['speed_m_s']['mean']:.3f} | {groups['post_turn']['yaw_rms_rad_s']['mean']:.3f} |")
    text += ['', 'Each speed/yaw cell averages ten central-2-m windows. Acceptance applies to every window, not these means. The limits at the primary cap are speed ≥0.95 m/s, yaw RMS ≤0.15 rad/s, and normalized steering RMS ≤0.02.', '',
             '![Straight recovery by candidate](straight-recovery-audit.png)', '',
             'Points show means and whiskers show the minimum–maximum across ten windows per group. They are not confidence intervals. All windows were observed.', '',
             '## All candidate results', '',
             '| Seed / generation | Primary | Retention | Paired time ratio | Shared finishes | Shared-finish RMSE (mm) | Rejection reasons |',
             '|---|---:|---:|---:|---:|---:|---|']
    for row in rows:
        gate = row['quality']
        text.append(f"| {row['seed']} / {row['generation']} | {row['primary_completed']}/60 | {row['retention_completed']}/20 | {gate['paired_time_ratio']:.4f} | {gate['shared_finishes']} | {gate['geometric_rmse_m']*1000:.2f} | {', '.join(gate['reasons'])} |")
    text += ['', 'Paired time is the ratio of mean completion times on tracks both candidate and corresponding parent finish. A ratio above 1.05 fails. Parent comparisons with themselves have ratio 1 by construction. RMSE uses that same candidate-specific shared-success set, so the denominators can differ.', '',
             '## Next step', '',
             'No existing model satisfies the requested combined target. Run the old-fitness continuation pilot and smooth-fitness pilot separately, then review the saved validation trade-offs. This audit does not demonstrate that either future pilot will succeed. PID tuning remains a separate stage; no PID was compared in this audit.', '',
             '```powershell',
             '& .\\.venv\\Scripts\\python.exe run_neat_smooth_study.py pilot --branch old --workers 2',
             '& .\\.venv\\Scripts\\python.exe run_neat_smooth_study.py pilot --branch smooth --workers 2',
             '& .\\.venv\\Scripts\\python.exe run_neat_smooth_study.py review-pilot',
             '```', '',
             'Run one branch at a time. This report only reads saved results; it starts no evolution, tuning or new simulations. Reproduce it with `& .\\.venv\\Scripts\\python.exe runs/neat-smooth-study-v1/audit-review/report.py`. The frozen source and protocol were verified before summarizing. `summary.json` preserves input hashes and the full numerical breakdown.']
    (OUT / 'report.md').write_text('\n'.join(text) + '\n', encoding='utf-8')
    print('Saved audit report, numerical summary and PNG/SVG figure. No new simulations or evolution.')


if __name__ == '__main__':
    main()
